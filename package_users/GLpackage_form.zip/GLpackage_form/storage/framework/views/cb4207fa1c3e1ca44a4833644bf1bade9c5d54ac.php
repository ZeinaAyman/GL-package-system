<?php $__env->startSection('title', 'Package Details'); ?>

<?php $__env->startSection('content'); ?>
<a href="/logout">Logout</a>

<?php if(isset($package)): ?>

    <h1><?php echo e(explode(' ',$package->member_name)[0]); ?>'s Package Details:</h1>

    <h3>Full name: <?php echo e($package->member_name); ?></h3>
    <h3>Student ID: <?php echo e($package->member_id); ?></h3>
    <h3>Serial Number: <?php echo e($package->serial_number); ?></h3>
    <div>
        <h3>Package Items:</h3>
        <ul>
            <?php if($package->tshirt): ?>
                <li>T-shirt</li>
            <?php endif; ?>
            <?php if($package->bracelet): ?>
                <li>Bracelet</li>
            <?php endif; ?>
            <?php if($package->nametag): ?>
                <li>Nametag</li>
            <?php endif; ?>
        </ul>
    </div>
    <h3>Amount: <?php echo e($package->amount); ?> EGP</h3>

    <div>
        <?php if($package->verified_at): ?>
            <h3>Verified by <?php echo e($package->username); ?> at <?php echo e(date('d-m-Y h:i A',strtotime($package->verified_at))); ?></h3>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="serial_number" value="<?php echo e($package->serial_number); ?>">
                <button type="submit" name="unverify">Unverify Payment</button>
            </form>
        <?php else: ?>
            <h3>Package not verified yet.</h3>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="serial_number" value="<?php echo e($package->serial_number); ?>">
                <button type="submit" name="verify">Verify Payment</button>
            </form>
    <?php endif; ?>
</div>
<?php else: ?>

    <?php if($errors->any()): ?>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <?php endif; ?>

    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="serial_number" placeholder="Serial Number">
        <button type="submit">Find</button>
    </form>
<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GL-Package-Form-System-main\resources\views//package/view.blade.php ENDPATH**/ ?>