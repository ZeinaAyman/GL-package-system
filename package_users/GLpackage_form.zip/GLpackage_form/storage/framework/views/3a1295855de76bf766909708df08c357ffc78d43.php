<?php $__env->startSection('title', 'Package Form'); ?>

<?php $__env->startSection('content'); ?>

    <?php if(isset($error)): ?>
        <h3><?php echo e($error); ?></h3>
    <?php endif; ?>

    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="username" id="username" placeholder="Username">
        <input type="password" name="password" id="password" placeholder="Password">
        <button type="submit">Log In</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\GL-Package-Form-System-main\resources\views/login.blade.php ENDPATH**/ ?>